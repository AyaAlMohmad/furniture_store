<?php

namespace App\Models;

use Astrotomic\Translatable\Translatable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Menu extends AppModel
{
    use Translatable;
    use HasFactory;
    protected $fillable=['name','image'];
    protected $translatedAttributes=['title','description','short_description','locale'];
}

<?php

namespace App\Http\Controllers\Api\product;

use App\Http\Controllers\Controller;
use App\Models\SubCategory;
use App\Traits\ApiResponseTrait;
use Illuminate\Http\Request;

class SubCategoryController extends Controller
{
    use ApiResponseTrait;
  
    public function index()
    {
        $categories = SubCategory::all();
        $data = [];


        foreach ($categories as $category) {
            // $video = $product->video;
            $id = $category->id;
            $acceptLanguage = request()->header('Accept-Language');
            
            $Category = $category->category->getTranslationsArray();
            $translations = $category->getTranslationsArray();
            if (isset($translations[$acceptLanguage])) {
                $selectedTranslation = $translations[$acceptLanguage];
               
                $selectedcategory=$Category[$acceptLanguage];
            } 
            $data[] = [
                'id' => $id,
                'Category' => $selectedcategory,
                'translations' => $selectedTranslation
            ];
        }
        return $this->indexResponse($data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\SubCategory  $subCategory
     * @return \Illuminate\Http\Response
     */
    public function show(SubCategory $subCategory)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\SubCategory  $subCategory
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, SubCategory $subCategory)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\SubCategory  $subCategory
     * @return \Illuminate\Http\Response
     */
    public function destroy(SubCategory $subCategory)
    {
        //
    }
}

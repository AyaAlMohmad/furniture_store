<?php

namespace App\Http\Controllers\Api\product;

use App\Http\Controllers\Controller;
use App\Models\Image;
use App\Models\ImageProduct;
use App\Models\Product;
use App\Models\Video;
use App\Traits\ApiResponseTrait;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    use ApiResponseTrait;
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($id)
    {
        // $id=$request->input('id_subcategory');
        $products = Product::where('sub_category_id', $id)->get();
        // $products=Product::all();
        $data = [];

        foreach ($products as $product) {
            $images = []; // Define $images here
            $acceptLanguage = request()->header('Accept-Language');
            $category = $product->subCategory->getTranslationsArray();
            $sub_category = $product->subCategory->getTranslationsArray();

            $translations = $product->getTranslationsArray();
            foreach ($product->images as $image) {
                $images[] = '/images/product/' . $image->image;
            }
            // $locale = request()->header('Accept-Language');
        

            // Use the locale to select the translation
            if (isset($translations[$acceptLanguage])) {
                $selectedTranslation = $translations[$acceptLanguage];
                $selectedSub_category=$sub_category[$acceptLanguage];
                $selectedcategory=$category[$acceptLanguage];
            } 
     
            $data[] = [
                'id' => $product->id,
                'category' => $selectedcategory,
                'sub_category' => $selectedSub_category,
                'translation' => $selectedTranslation,
                'images' => $images,
            ];
        }

        return $this->indexResponse($data);
    }

    public function catalge()
    {
        $products = Product::all();

        $data = [];

        $images = [];
        $color = [];
        foreach ($products as $product) {
            // $video = $product->video;
            $price = $product->price;
            $acceptLanguage = request()->header('Accept-Language');
            $sub_category = $product->subCategory->getTranslationsArray();
            $category = $product->subCategory->getTranslationsArray();
            $translations = $product->getTranslationsArray();
            foreach ($product->images as $image) {
                $images[] = 'images/product/' . $image->image;
            }
          // Use the locale to select the translation
          if (isset($translations[$acceptLanguage])) {
            $selectedTranslation = $translations[$acceptLanguage];
            $selectedSub_category=$sub_category[$acceptLanguage];
            $selectedcategory=$category[$acceptLanguage];
        } 
 

            $data[] = [
                'id' => $product->id,
                'price' => $price,
                'category' => $selectedcategory,

                // 'designer_description' => $designer_description,
                'sub_category' => $selectedSub_category,
                'translation' => $selectedTranslation,
                // 'color'=>$color,
                // 'video'=>$video,
                'images' => $images,
            ];
        }
        return $this->indexResponse($data);
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $product = Product::find($id);
        $Images = ImageProduct::where('product_id', $product->id)->get();

        $images = [];
        $color = [];
        $video = 'videos/product/' . $product->video;
        $price = $product->price;
        // $designer_name = $product->designer->name;
        // $designer_image = 'images/designer/' . $product->designer->image;
        // $designer_description = $product->designer->description;
        $acceptLanguage = request()->header('Accept-Language');
            $sub_category = $product->subCategory->getTranslationsArray();
            $category = $product->subCategory->getTranslationsArray();
            $translations = $product->getTranslationsArray();
        foreach ($Images as $image) {
            $images[] = 'images/product/' . $image->image;
        }
          // Use the locale to select the translation
          if (isset($translations[$acceptLanguage])) {
            $selectedTranslation = $translations[$acceptLanguage];
            $selectedSub_category=$sub_category[$acceptLanguage];
            $selectedcategory=$category[$acceptLanguage];
        } 
        foreach ($product->colors as $individualColor) {
            $imag = 'images/color/' . $individualColor->image;
            $translatedColor = [
                'image' => $imag,
                'translation' => $individualColor->getTranslationsArray()
            ];
            $color[] = $translatedColor;
        }


        $data = [
            'id' => $product->id,
            'price' => $price,
            // 'designer_name' => $designer_name,
            // 'designer_image' => $designer_image,
            // 'designer_description' => $designer_description,
            'category' => $selectedcategory,
            'sub_category' => $selectedSub_category,
            'translation' => $selectedTranslation,
            'video' => $video,
            'images' => $images,
            'color' => $color
        ];
        return $this->showResponse($data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Product $product)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function destroy(Product $product)
    {
        //
    }
    public function imageVideo()
    {
        $image=Image::all();
        $video=Video::all();
        foreach($image as $data){
        $images[] = 'images/slider/' . $data->image;}
        foreach($video as $item){
        $videos[] = 'videos/slider/' . $item->video;
        }
        $data = [
            'image' => $images,
            'video' => $videos
        ];
        return $this->indexResponse($data);
    }
}

<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use App\Http\Requests\ProductRequest;
use App\Models\Color;
use App\Models\ColorProduct;
use App\Models\Designer;
use App\Models\ImageProduct;
use App\Models\Product;
use App\Models\SubCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\File;


class ProductController extends DashboardController
{

    public function __construct(Product $model)
    {
        parent::__construct();
        $this->model = $model;
        $this->module_actions = ['destroy', 'create', 'index', 'store', 'update', 'show', 'edit', 'recycleBin'];
        view()->share([
            'module_actions' => $this->module_actions,
        ]);
    }
    public function create()
    {
        $items = SubCategory::all();
        $designers = Designer::all();
        $colors = Color::all();
        return view('dashboard.pages.products.form', compact('colors', 'items', 'designers'));
    }

    // ************************************************
    // ************************************************
    // ***********************Store********************
    // ************************************************
    public function store(ProductRequest $request)
    {
        $video = request()->file('video');
        $videoName = time() . '.' . $video->extension();
        $video->move(public_path('videos/product'), $videoName);
        $product = Product::create([
            'price' => $request->price,
            'designer_id' => $request->designer_id,
            'sub_category_id' => $request->sub_category_id,
            'video' => $videoName
        ]);

        // Store the colors
        foreach ($request->color_id as $colorId) {
            ColorProduct::create([
                'product_id' => $product->id,
                'color_id' => $colorId,
            ]);
        }
        if ($request->has('images')) {
            foreach ($request->images as $image) {
                // Make a image name based on user name and current timestamp
                $imageName = Str::random(40) . '.' . $image->getClientOriginalExtension();

                // Move the image to the correct location
                $image->move(public_path('images/product'), $imageName);
                // $fullPath = asset('images/product/' . $imageName);

                // Save image details into the database
                $product->images()->create(['image' => $imageName]);

               
            }
        }
        // Store the images
        // foreach ($request->images as $image) {
        //     // $image = request()->file('image');
        //     $imageName = time() . '.' . $image->extension();
        //     $image->move(public_path('images/product'), $imageName);
        //     ImageProduct::create([
        //         'product_id' => $product->id,
        //         'image' => $imageName,
        //     ]);
        // }

        foreach ($request->all() as $locale => $data) {
            if (is_array($data) && isset($data['name'])) {
                $product->translateOrNew($locale)->name = $data['name'];
            }
            if (is_array($data) && isset($data['material'])) {
                $product->translateOrNew($locale)->material = $data['material'];
            }
       
            if (is_array($data) && isset($data['description'])) {
                $product->translateOrNew($locale)->description = $data['description'];
            }
        }

        $product->save();


        return redirect($this->index_route);
    }

    public function edit($id)
    {
        $product = Product::findOrFail($id);
        $items = SubCategory::all();
        $designers = Designer::all();
        $colors = Color::all();
        return view('dashboard.pages.products.edit', compact('product', 'colors', 'items', 'designers'));
    }
    // ************************************************
    // ************************************************
    // ***********************Update*******************
    // ************************************************
    // ************************************************
    public function update(ProductRequest $request, Product $product)
    {
        $data = $request->all();

        // Delete old video if exists
        if (request()->hasFile('video') && request('video') != '') {
            $videoPath = public_path('videos/product/' . $product->video);
            if (File::exists($videoPath)) {
                unlink($videoPath);
            }


            // Move new video to destination directory
            $video = request()->file('video');
            $videoName = time() . '.' . $video->extension();
            $video->move(public_path('videos/product'), $videoName);
            $data['video'] = $videoName;
            // Update product data
            $product->update($data);
        } else {
            $product->update($data);
        }
        // Delete old images if exists
        if (request()->hasFile('images') && request('images') != '') {
            $imagePath = public_path('images/product/' . $product->image);
            if (File::exists($imagePath)) {
                unlink($imagePath);
            }


            // Move new images to destination directory
            foreach ($request->images as $image) {
                $imageName = time() . '.' . $image->extension();
                $image->move(public_path('images/product'), $imageName);

                // Retrieve ImageProduct instance and update it
                $imageProduct = ImageProduct::where('product_id', $product->id)->first();
                if ($imageProduct) {
                    $imageProduct->update(['image' => $imageName]);
                } else {
                    ImageProduct::create([
                        'product_id' => $product->id,
                        'image' => $imageName,
                    ]);
                }
            }
        }
        if ($request->color_id) {

            // Update color products
            foreach ($request->color_id as $colorId) {
                $colorProduct = ColorProduct::where('product_id', $product->id)->first();
                if ($colorProduct) {
                    $colorProduct->update(['color_id' => $colorId]);
                } else {
                    ColorProduct::create([
                        'product_id' => $product->id,
                        'color_id' => $colorId,
                    ]);
                }
            }
        }
        return redirect($this->index_route);
    }
}

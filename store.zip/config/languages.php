<?php
return[
    'fr' =>['display'=> 'French', 'flag-icon' => 'fr',],
    'en' => [ 'display' => 'English', 'flag-icon' => 'us', ]
];
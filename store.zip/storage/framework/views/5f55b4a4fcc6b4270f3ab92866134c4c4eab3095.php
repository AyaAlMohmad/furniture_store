
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
        <title>Zinzer - Responsive Bootstrap 4 Admin Dashboard</title>
        <meta content="Admin Dashboard" name="description" />
        <meta content="ThemeDesign" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />

        <link rel="shortcut icon" href="<?php echo e(asset('dashboard/assets/images/favicon.ico')); ?>">

        <!-- morris css -->
        <link rel="stylesheet" href="<?php echo e(asset('dashboard/plugins/morris/morris.css')); ?>">

        <link href="<?php echo e(asset('dashboard/assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('dashboard/assets/css/icons.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('dashboard/assets/css/style.css')); ?>" rel="stylesheet" type="text/css">

    </head>


    <body class="fixed-left">

        <!-- Loader -->
        <div id="preloader">
            <div id="status">
                <div class="spinner">
                    <div class="rect1"></div>
                    <div class="rect2"></div>
                    <div class="rect3"></div>
                    <div class="rect4"></div>
                    <div class="rect5"></div>
                </div>
            </div>
        </div>

        <!-- Begin page -->
        <div id="wrapper">

            <!-- ========== Left Sidebar Start ========== -->
            <?php echo $__env->make('dashboard.layout.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Left Sidebar End -->

            <!-- Start right Content here -->

            <div class="content-page">
                <!-- Start content -->
                <div class="content">

                    <!-- Top Bar Start -->
                  <?php echo $__env->make('dashboard.layout.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <!-- Top Bar End -->

                    <div class="page-content-wrapper ">

                        
                        <?php if($message = \Session::get('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e($message); ?>

                        </div>
                    <?php endif; ?>
                    <?php if($message = \Session::get('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($message); ?>

                        </div>
                    <?php endif; ?>


                    <?php echo $__env->yieldContent('content'); ?>
                    </div> <!-- Page content Wrapper -->

                </div> <!-- content -->

                <?php echo $__env->make('dashboard.layout.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        

            </div>
            <!-- End Right content here -->

        </div>
        <!-- END wrapper -->


        <!-- jQuery  -->
        <script src="<?php echo e(asset('dashboard/assets/js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('dashboard/assets/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('dashboard/assets/js/modernizr.min.js')); ?>"></script>
        <script src="<?php echo e(asset('dashboard/assets/js/detect.js')); ?>"></script>
        <script src="<?php echo e(asset('dashboard/assets/js/fastclick.js')); ?>"></script>
        <script src="<?php echo e(asset('dashboard/assets/js/jquery.slimscroll.js')); ?>"></script>
        <script src="<?php echo e(asset('dashboard/assets/js/jquery.blockUI.js')); ?>"></script>
        <script src="<?php echo e(asset('dashboard/assets/js/waves.js')); ?>"></script>
        <script src="<?php echo e(asset('dashboard/assets/js/jquery.nicescroll.js')); ?>"></script>
        <script src="<?php echo e(asset('dashboard/assets/js/jquery.scrollTo.min.js')); ?>"></script>

        <!--Morris Chart-->
        <script src="<?php echo e(asset('dashboard/plugins/morris/morris.min.js')); ?>"></script>
        <script src="<?php echo e(asset('dashboard/plugins/raphael/raphael.min.js')); ?>"></script>

        <!-- dashboard js -->
        <script src="<?php echo e(asset('dashboard/assets/pages/dashboard.int.js')); ?>"></script>        

        <!-- App js -->
        <script src="<?php echo e(asset('dashboard/assets/js/app.js')); ?>"></script>

    </body>
</html><?php /**PATH C:\laragon\www\DashTempWhite\resources\views/dashboard/layout/dashboard.blade.php ENDPATH**/ ?>
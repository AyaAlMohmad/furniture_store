<div class="left side-menu">
    <button type="button" class="button-menu-mobile button-menu-mobile-topbar open-left waves-effect">
        <i class="mdi mdi-close"></i>
    </button>

    <div class="left-side-logo d-block d-lg-none">
        <div class="text-center">
            <a href="index.html" class="logo"><img src="<?php echo e(asset('dashboard/assets/images/logo.png')); ?>" height="20"
                    alt="logo"></a>
        </div>
    </div>

    <div class="sidebar-inner slimscrollleft">

        <div id="sidebar-menu">
            <ul>
                <li class="menu-title">Main</li>

                <li class="<?php echo e(Request::route()->getName() == 'dash.index' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('dash.index')); ?>" class="waves-effect">

                        <i class="dripicons-home"></i>
                        <span> Dashboard </span>
                    </a>
                </li>

                <li class=" <?php echo e(Request::route()->getName() == 'abouts.index' ? 'active' : ''); ?>">

                    <a href="<?php echo e(route('abouts.index')); ?>"><i class="dripicons-briefcase"></i>
                        <span> About </span>
                    </a>

                </li>


            </ul>
        </div>
        <div class="clearfix"></div>
    </div> <!-- end sidebarinner -->
</div>
<?php /**PATH C:\laragon\www\Hadeaa\resources\views/dashboard/layout/includes/sidebar.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card m-b-30">
                <div class="card-body">
                    <ul class="nav nav-tabs" id="myTab2">
                        <?php $__currentLoopData = config('app.languages'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="<?php echo e($lang == 'Turkish' ? 'active' : ''); ?>">
                                <a data-toggle="tab" class="nav-link" href="#<?php echo e($key); ?>"><?php echo e($lang); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <div class="tab-content padding-4">
                        <?php $__currentLoopData = config('app.languages'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!-- div.dataTables_borderWrap -->
                            <div class="tab-pane <?php echo e($lang == 'Turkish' ? 'active' : ''); ?>" id="<?php echo e($key); ?>">

                                <table id="datatable-buttons"
                                    class="table table-striped table-bordered dt-responsive nowrap"
                                    style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                    <thead>
                                        <tr>
                                            <th ><?php echo e(__('dashboard.image', [], $key)); ?></th>
                                            <th ><?php echo e(__('dashboard.name', [], $key)); ?></th>
                                            <th ><?php echo e(__('dashboard.title', [], $key)); ?></th>
                                            <th ><?php echo e(__('dashboard.short_description', [], $key)); ?></th>
                                            <th ><?php echo e(__('dashboard.description', [], $key)); ?></th>
                                            <th ><?php echo e(__('dashboard.actions', [], $key)); ?></th>

                                        </tr>
                                    </thead>


                                    <tbody>
                                        <?php $__currentLoopData = $items->where('locale', $key); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><img style="width: 90px; height: 90px;"
                                                        src="<?php echo e(asset('images/menu/' . $data->image)); ?>"></td>
                                                <td><?php echo e($data->name); ?></td>
                                                <td><?php echo e($data->title); ?></td>
                                                <td style="word-break: break-all;"><?php echo e($data->short_description); ?></td>
                                                <td style="word-break: break-all;"><?php echo e($data->description); ?></td>

                                                <td>
                                                    <div class="hidden-sm hidden-xs action-buttons" style="display:flex;">
                                                        <a style="color:green" href="<?php echo e(route('menus.edit', $data->id)); ?>">
                                                            <i class="fas fa-feather bigger-120"
                                                                style="margin-right: 10px;"> </i>
                                                        </a>
                                                        <a style="color:blue" href="<?php echo e(route('menus.show', $data->id)); ?>">
                                                            <i class="dripicons-zoom-in bigger-120"
                                                                style="margin-right: 10px;"></i>
                                                        </a>
                                                        <form method="POST"
                                                            action="<?php echo e(route('menus.destroy', $data->id)); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button style="border: none; color:white;">
                                                                <i class="ace-icon dripicons-trash bigger-120"
                                                                    style="color: red;"></i>
                                                            </button>
                                                        </form>

                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div> <!-- end col -->
            </div>
        </div>
    </div>
    
            <!-- end row -->
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\store\resources\views/dashboard/pages/menus/index.blade.php ENDPATH**/ ?>
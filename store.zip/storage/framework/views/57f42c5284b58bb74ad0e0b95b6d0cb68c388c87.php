

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card m-b-30">
                <form class="form-horizontal" role="form" method="POST" enctype="multipart/form-data"
                    action="<?php echo e(route('role_users.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <div class="widget-main">

                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          
                            <div class="form-group">
                                <label  > <?php echo e(__('dashboard.username')); ?>:  </label> 
                               
                                <input   name="user_id" type="hidden" value="<?php echo e($item->id); ?>">
                                <?php echo e($item->name); ?>

                            </div>
                            <div class="form-group">
                                <label for="role_id">
                                    <?php echo app('translator')->get('dashboard.role'); ?>:
                                </label>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="role_id"
                                            id="role_<?php echo e($role->id); ?>" value="<?php echo e($role->id); ?>">
                                        <label class="form-check-label" for="role_<?php echo e($role->id); ?>">
                                            <?php echo e($role->role_name); ?>

                                        </label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="dropdown-divider"></div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="col-sm-6 control-label no-padding-right">
                            <button type="submit" class="btn btn-sm btn-primary">save</button>
                        </div>


                    </div>
            </div>

            </form>
        </div>
    </div> <!-- end col -->
    </div> <!-- end row -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\store\resources\views/dashboard/pages/role_users/form.blade.php ENDPATH**/ ?>
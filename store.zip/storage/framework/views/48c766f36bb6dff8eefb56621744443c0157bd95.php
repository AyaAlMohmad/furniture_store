

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card m-b-30">



                <form class="form-horizontal" role="form" method="POST" enctype="multipart/form-data"
                    action="<?php echo e(route('products.update', $product->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>

                    <div class="widget-main">

                        <div class="tab-content padding-4">
                            <div class="form-group">
                                <label for="name">
                                    <?php echo e(__('dashboard.name')); ?>

                                </label>

                                <input class="form-control" required type="text" name="name"
                                    value="<?php echo e($product->name); ?>">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div><br><br>


                            <div class="form-group">

                                <label for="description]">
                                    <?php echo e(__('dashboard.description')); ?>

                                </label>
                                <div>
                                    <textarea name="description" class="form-control" required placeholder="Description" rows="5"><?php echo e($product->description); ?></textarea>
                                </div>
                                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>

                        </div>

                        <div class="form-group">
                            <label for="price">
                                <?php echo app('translator')->get('dashboard.price'); ?>

                            </label>

                            <input class="form-control" required type="text" name="price"
                                value="<?php echo e($product->price); ?>">
                            <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div><br><br>
                        <div class="form-group">
                            <label for="designer_id">
                                <?php echo app('translator')->get('dashboard.designer'); ?>

                            </label>
                            <select name="designer_id" id="designer_id">
                                <option value="<?php echo e($product->designer_id); ?>"><?php echo e($product->designer->name); ?> ..</option>>
                                <?php $__currentLoopData = $designers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($designer->id); ?>"><?php echo e($designer->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                        </div>
                        <div class="form-group">
                            <label for="sub_category_id">
                                <?php echo app('translator')->get('dashboard.SubCategory'); ?>
                            </label>
                            <select name="sub_category_id" id="sub_category_id">
                                <option value="<?php echo e($product->sub_category_id); ?>"><?php echo e($product->subCategory->name); ?> ..
                                </option>>
                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                        </div>






                        <div class="form-group">
                            <label for="file" class="col-sm-2 control-label no-padding-right"><?php echo app('translator')->get('dashboard.image'); ?>
                            </label>
                            <div>

                                <div class="form-group">
                                    <div class="col-xs-9">
                                        <input type="file" name="images[]" id="id-input-file-3" multiple>

                                        <!-- /section:custom/file-input -->
                                    </div>
                                    <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <img src="<?php echo e(asset('images/product/' . $image->image)); ?>" width="100"
                                            height="100">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>
                            <?php $__env->startPush('js'); ?>
                                <script type="text/javascript">
                                    jQuery(function($) {




                                        //pre-show a file name, for example a previously selected file
                                        //$('#id-input-file-1').ace_file_input('show_file_list', ['myfile.txt')


                                        $('#id-input-file-3').ace_file_input({
                                            style: 'well',
                                            btn_choose: 'Drop files here or click to choose',
                                            btn_change: null,
                                            no_icon: 'ace-icon fa fa-cloud-upload',
                                            droppable: true,
                                            thumbnail: 'small' //large | fit
                                                //,icon_remove:null//set null, to hide remove/reset button
                                                /**,before_change:function(files, dropped) {
                                                    //Check an example below
                                                    //or examples/file-upload.html
                                                    return true;
                                                }*/
                                                /**,before_remove : function() {
                                                    return true;
                                                }*/
                                                ,
                                            preview_error: function(filename, error_code) {
                                                //name of the file that failed
                                                //error_code values
                                                //1 = 'FILE_LOAD_FAILED',
                                                //2 = 'IMAGE_LOAD_FAILED',
                                                //3 = 'THUMBNAIL_FAILED'
                                                //alert(error_code);
                                            }

                                        }).on('change', function() {
                                            //console.log($(this).data('ace_input_files'));
                                            //console.log($(this).data('ace_input_method'));
                                        });


                                        //$('#id-input-file-3')
                                        //.ace_file_input('show_file_list', [
                                        //{type: 'image', name: 'name of image', path: 'http://path/to/image/for/preview'},
                                        //{type: 'file', name: 'hello.txt'}
                                        //]);




                                        /////////
                                        $('#modal-form input[type=file]').ace_file_input({
                                            style: 'well',
                                            btn_choose: 'Drop files here or click to choose',
                                            btn_change: null,
                                            no_icon: 'ace-icon fa fa-cloud-upload',
                                            droppable: true,
                                            thumbnail: 'large'

                                        })

                                        //chosen plugin inside a modal will have a zero width because the select element is originally hidden
                                        //and its width cannot be determined.
                                        //so we set the width after modal is show
                                        $('#modal-form').on('shown.bs.modal', function() {
                                            if (!ace.vars['touch']) {
                                                $(this).find('.chosen-container').each(function() {
                                                    $(this).find('a:first-child').css('width', '210px');
                                                    $(this).find('.chosen-drop').css('width', '210px');
                                                    $(this).find('.chosen-search input').css('width', '200px');
                                                });
                                            }
                                        })
                                        /**
                                        //or you can activate the chosen plugin after modal is shown
                                        //this way select element becomes visible with dimensions and chosen works as expected
                                        $('#modal-form').on('shown', function () {
                                            $(this).find('.modal-chosen').chosen();
                                        })
                                        */



                                        $(document).one('ajaxloadstart.page', function(e) {
                                            $('textarea[class*=autosize]').trigger('autosize.destroy');
                                            $('.limiterBox,.autosizejs').remove();
                                            $('.daterangepicker.dropdown-menu,.colorpicker.dropdown-menu,.bootstrap-datetimepicker-widget.dropdown-menu')
                                                .remove();
                                        });

                                    });
                                </script>
                            <?php $__env->stopPush(); ?>


                        </div>
                        <div class="card-body">

                            <h4 class="mt-0 header-title"><?php echo app('translator')->get('dashboard.video'); ?></h4>


                            <div class="m-b-30">
                                <form action="#" class="dropzone">
                                    <div class="fallback">
                                        <input name="video" type="file" multiple="multiple">


                                    </div>
                                    <video src="<?php echo e(asset('videos/product/' . $product->video)); ?>" width="100"
                                        height="100">

                                </form>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-6 control-label no-padding-right">
                                <button type="submit" class="btn btn-sm btn-primary"><i
                                        class="fa fa-save"></i>save</button>
                            </div>
                        </div>


                    </div>
                </form>
            </div>
        </div> <!-- end col -->
    </div>
    <script>
        function previewFile(input) {
            var file = $("input[type=file]").get(0).files[0];
            if (file) {
                var reader = new FileReader();
                reader.onload = function() {
                    $("#previewImage").attr("src", reader.result);
                }
                reader.readAsDataURL(file);


            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\store\resources\views/dashboard/pages/products/edit.blade.php ENDPATH**/ ?>
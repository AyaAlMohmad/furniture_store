<?php

use App\Http\Controllers\Dashboard\AboutController;
use App\Http\Controllers\Dashboard\CategoryController;
use App\Http\Controllers\Dashboard\ColorController;
use App\Http\Controllers\Dashboard\DashController;
use App\Http\Controllers\Dashboard\DesignerController;
use App\Http\Controllers\Dashboard\MenuController;
use App\Http\Controllers\Dashboard\ProductController;
use App\Http\Controllers\Dashboard\RoleController;
use App\Http\Controllers\Dashboard\RoleUserController;
use App\Http\Controllers\Dashboard\SocialController;
use App\Http\Controllers\Dashboard\SubCategoryController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('lang/{lang}', ['as' => 'lang.switch', 'uses' => '\App\Http\Controllers\LocaleController@switchLang']); 

Route::prefix('dash/')->middleware(['auth','localized'])->group(function () {
    Route::get('/', [DashController::class, 'index'])->name('dash.index');
   
    Route::resource('menus', MenuController::class);
    Route::get('Softmenus', [MenuController::class, 'recycleBin'])->name('menus.soft');
    Route::get('menus/finldelete/{id}', [MenuController::class, 'finalDelete'])->name('menus.finaldelete');
    Route::get('menus/restore/{id}', [MenuController::class, 'restore'])->name('menus.restore');

   
    Route::resource('abouts', AboutController::class);
    Route::get('SoftAbouts', [AboutController::class, 'recycleBin'])->name('abouts.soft');
    Route::get('abouts/finldelete/{id}', [AboutController::class, 'finalDelete'])->name('abouts.finaldelete');
    Route::get('abouts/restore/{id}', [AboutController::class, 'restore'])->name('abouts.restore');




    Route::resource('categories', CategoryController::class);
    Route::get('Softcategories', [CategoryController::class, 'recycleBin'])->name('categories.soft');
    Route::get('categories/finldelete/{id}', [CategoryController::class, 'finalDelete'])->name('categories.finaldelete');
    Route::get('categories/restore/{id}', [CategoryController::class, 'restore'])->name('categories.restore');

    
    Route::resource('sub_categories', SubCategoryController::class);
    Route::get('Softsub_categories', [SubCategoryController::class, 'recycleBin'])->name('sub_categories.soft');
    Route::get('sub_categories/finldelete/{id}', [SubCategoryController::class, 'finalDelete'])->name('sub_categories.finaldelete');
    Route::get('sub_categories/restore/{id}', [SubCategoryController::class, 'restore'])->name('sub_categories.restore');



    Route::resource('products', ProductController::class);
    Route::get('Softproducts', [ProductController::class, 'recycleBin'])->name('products.soft');
    Route::get('products/finldelete/{id}', [ProductController::class, 'finalDelete'])->name('products.finaldelete');
    Route::get('products/restore/{id}', [ProductController::class, 'restore'])->name('products.restore');
    
    Route::resource('designers', DesignerController::class);
    Route::get('Softdesigners', [DesignerController::class, 'recycleBin'])->name('designers.soft');
    Route::get('designers/finldelete/{id}', [DesignerController::class, 'finalDelete'])->name('designers.finaldelete');
    Route::get('designers/restore/{id}', [DesignerController::class, 'restore'])->name('designers.restore');
    


    Route::resource('colors', ColorController::class);
    Route::get('Softcolors', [ColorController::class, 'recycleBin'])->name('colors.soft');
    Route::get('colors/finldelete/{id}', [ColorController::class, 'finalDelete'])->name('colors.finaldelete');
    Route::get('colors/restore/{id}', [ColorController::class, 'restore'])->name('colors.restore');
    

    Route::resource('socials', SocialController::class);
    Route::get('Softsocials', [SocialController::class, 'recycleBin'])->name('socials.soft');
    Route::get('socials/finldelete/{id}', [SocialController::class, 'finalDelete'])->name('socials.finaldelete');
    Route::get('socials/restore/{id}', [SocialController::class, 'restore'])->name('socials.restore');
    

    Route::resource('roles', RoleController::class);
    Route::get('Softroles', [RoleController::class, 'recycleBin'])->name('roles.soft');
    Route::get('roles/finldelete/{id}', [RoleController::class, 'finalDelete'])->name('roles.finaldelete');
    Route::get('roles/restore/{id}', [RoleController::class, 'restore'])->name('roles.restore');
    
    Route::resource('role_users', RoleUserController::class);


});
